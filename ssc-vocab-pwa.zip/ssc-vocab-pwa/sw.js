const CACHE_NAME = 'ssc-vocab-v1';
const ASSETS = ['/', '/index.html', '/manifest.json'];

// ── Install ──────────────────────────────────────────────
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(c => c.addAll(ASSETS))
  );
  self.skipWaiting();
});

// ── Activate ─────────────────────────────────────────────
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// ── Fetch (offline support) ───────────────────────────────
self.addEventListener('fetch', e => {
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request))
  );
});

// ── Scheduled Notification Alarm ─────────────────────────
// Main page posts { type:'SCHEDULE', slots:[...], words:[...] }
// SW stores them and fires notifications at the right time

let scheduledAlarms = [];
let wordList = [];
let alarmTimers = [];
let lastWordIndex = -1;

self.addEventListener('message', e => {
  const data = e.data;

  if (data.type === 'SCHEDULE') {
    wordList = data.words || [];
    clearAllAlarms();
    scheduledAlarms = data.slots || [];
    scheduleAll();
  }

  if (data.type === 'CANCEL') {
    clearAllAlarms();
  }

  if (data.type === 'UPDATE_WORDS') {
    wordList = data.words || [];
  }
});

function clearAllAlarms() {
  alarmTimers.forEach(t => clearTimeout(t));
  alarmTimers = [];
}

function scheduleAll() {
  if (!wordList.length || !scheduledAlarms.length) return;

  const now = new Date();

  scheduledAlarms.forEach(slot => {
    const [h, m] = slot.split(':').map(Number);

    // Calculate next occurrence
    let target = new Date(now);
    target.setHours(h, m, 0, 0);
    if (target <= now) target.setDate(target.getDate() + 1);

    const delay = target - now;

    const tid = setTimeout(function fireAndReschedule() {
      showVocabNotification();
      // Reschedule for next day (24h later)
      const nextTid = setTimeout(fireAndReschedule, 24 * 60 * 60 * 1000);
      alarmTimers.push(nextTid);
    }, delay);

    alarmTimers.push(tid);
  });
}

function getRandomWord() {
  if (!wordList.length) return null;
  let idx;
  let tries = 0;
  do {
    idx = Math.floor(Math.random() * wordList.length);
    tries++;
  } while (wordList.length > 1 && idx === lastWordIndex && tries < 10);
  lastWordIndex = idx;
  return wordList[idx];
}

function showVocabNotification() {
  const w = getRandomWord();
  if (!w) return;

  const typeEmoji = w.type === 'idiom' ? '💬' : w.type === 'phrase' ? '📝' : '📖';
  const title = `${typeEmoji} ${w.word}`;
  const body  = w.meaning || 'Tap to open app';

  self.registration.showNotification(title, {
    body,
    icon:    '/icons/icon-192.png',
    badge:   '/icons/icon-192.png',
    tag:     'ssc-vocab-' + Date.now(),
    vibrate: [200, 100, 200],
    data:    { word: w.word, meaning: w.meaning },
    actions: [
      { action: 'next',    title: '➜ Next Word' },
      { action: 'dismiss', title: '✕ Dismiss'   }
    ],
    requireInteraction: false,
  });
}

// ── Notification Click ────────────────────────────────────
self.addEventListener('notificationclick', e => {
  e.notification.close();

  if (e.action === 'next') {
    showVocabNotification();
    return;
  }

  // Open app on tap
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      if (list.length) return list[0].focus();
      return clients.openWindow('/');
    })
  );
});
